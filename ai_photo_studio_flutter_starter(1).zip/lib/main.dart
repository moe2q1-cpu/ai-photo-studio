import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const PhotoStudioApp());

class PhotoStudioApp extends StatelessWidget {
  const PhotoStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'استوديو الصور',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const EditorPage(),
    );
  }
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  final ImagePicker _picker = ImagePicker();
  File? _photo;
  double _brightness = 1.0;
  double _contrast = 1.0;
  String _preset = 'أصلي';

  Future<void> _choosePhoto() async {
    final XFile? picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _photo = File(picked.path);
        _brightness = 1.0;
        _contrast = 1.0;
        _preset = 'أصلي';
      });
    }
  }

  void _applyPreset(String name) {
    setState(() {
      _preset = name;
      switch (name) {
        case 'مشرق':
          _brightness = 1.12;
          _contrast = 0.92;
          break;
        case 'داكن':
          _brightness = 0.82;
          _contrast = 1.12;
          break;
        case 'ناعم':
          _brightness = 1.06;
          _contrast = 0.88;
          break;
        default:
          _brightness = 1.0;
          _contrast = 1.0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استوديو الصور')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AspectRatio(
            aspectRatio: 4 / 5,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(20),
              ),
              child: _photo == null
                  ? const Center(child: Text('اختر صورة من هاتفك للبدء'))
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: ColorFiltered(
                        colorFilter: ColorFilter.matrix(_colorMatrix()),
                        child: Image.file(_photo!, fit: BoxFit.contain),
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _choosePhoto,
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('اختيار صورة'),
          ),
          const SizedBox(height: 20),
          const Text('الفلاتر'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: ['أصلي', 'مشرق', 'داكن', 'ناعم']
                .map((name) => ChoiceChip(
                      label: Text(name),
                      selected: _preset == name,
                      onSelected: (_) => _applyPreset(name),
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),
          Text('الإضاءة: ${_brightness.toStringAsFixed(2)}'),
          Slider(
            min: 0.6,
            max: 1.4,
            value: _brightness,
            onChanged: (v) => setState(() {
              _brightness = v;
              _preset = 'مخصص';
            }),
          ),
          Text('التباين: ${_contrast.toStringAsFixed(2)}'),
          Slider(
            min: 0.6,
            max: 1.5,
            value: _contrast,
            onChanged: (v) => setState(() {
              _contrast = v;
              _preset = 'مخصص';
            }),
          ),
          const SizedBox(height: 12),
          const Text(
            'هذه نسخة تجريبية: تعرض تأثيرات لونية على الصورة، '
            'ولا تتضمن بعدُ حفظ النسخة المعدّلة أو ذكاءً اصطناعيًا توليديًا.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  List<double> _colorMatrix() {
    final b = _brightness;
    final c = _contrast;
    final t = 128 * (1 - c);
    return [
      c, 0, 0, 0, t + (b - 1) * 255,
      0, c, 0, 0, t + (b - 1) * 255,
      0, 0, c, 0, t + (b - 1) * 255,
      0, 0, 0, 1, 0,
    ];
  }
}
